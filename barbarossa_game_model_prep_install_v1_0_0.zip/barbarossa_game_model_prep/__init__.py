bl_info = {
    "name": "BarBarossa Game Model Prep (v3.1.5)",
    "author": "BarBarossa Media (S. Letz)",
    "version": (3, 1, 5),
    "blender": (4, 0, 0),
    "location": "View3D > Sidebar > Game Prep",
    "description": "Prepare game-ready models: cleanup, scale, decimate, repair, shading, positioning, and smart export.",
    "category": "Object",
}

import bpy
import bmesh
from mathutils import Vector
import math
import os

# ---------------------------------------------------------
# Helper Functions
# ---------------------------------------------------------

def ensure_mesh(context):
    """Ensure we have a valid mesh object.
    Tries active_object first, then falls back to selected_objects.
    Also sets view_layer.objects.active if needed.
    """
    obj = context.view_layer.objects.active

    # if no active or not a mesh, try selected_objects
    if obj is None or obj.type != 'MESH':
        sel = [o for o in context.selected_objects if o.type == 'MESH']
        if sel:
            obj = sel[0]
            context.view_layer.objects.active = obj

    if obj is None:
        raise Exception("No mesh object selected.")
    if obj.type != 'MESH':
        raise Exception("Active object is not a mesh.")

    return obj


def merge_by_distance_auto(obj, dist=0.0001):
    """
    Universal Merge-by-Distance:
    ✔ Uses mesh.remove_doubles if available (legacy)
    ✔ Falls back to BMesh (always works)
    """
    ops = bpy.ops.mesh

    # Legacy operator (exists in many 4.x builds)
    if hasattr(ops, "remove_doubles"):
        bpy.ops.mesh.remove_doubles(threshold=dist)
        return

    # Fallback via BMesh
    me = obj.data
    bm = bmesh.new()
    bm.from_mesh(me)
    bmesh.ops.remove_doubles(bm, verts=bm.verts, dist=dist)
    bm.to_mesh(me)
    bm.free()
    me.update()


# ---------------------------------------------------------
# Settings / Stats
# ---------------------------------------------------------

class GMPSettings(bpy.types.PropertyGroup):
    target_size: bpy.props.FloatProperty(
        name="Target size",
        default=1.0,
        min=0.01,
        max=100.0,
        description="Largest dimension after scaling"
    )

    decimate_ratio: bpy.props.FloatProperty(
        name="Decimate ratio",
        default=0.25,
        min=0.01,
        max=1.0,
        description="Fraction of original polycount to keep"
    )

    autosmooth_angle: bpy.props.FloatProperty(
        name="Auto smooth angle",
        default=30.0,
        min=1.0,
        max=80.0,
        description="Angle for auto-smooth (in degrees)"
    )

    triangulate: bpy.props.BoolProperty(
        name="Triangulate",
        default=False,
        description="Triangulate mesh after repair"
    )

    pos_move_to_origin: bpy.props.BoolProperty(
        name="Move to (0,0,0)",
        default=True,
        description="Move object to world origin"
    )

    pos_snap_floor: bpy.props.BoolProperty(
        name="Snap to floor (Z=0)",
        default=False,
        description="Snap lowest point to Z=0"
    )

    pos_zero_rotation: bpy.props.BoolProperty(
        name="Zero rotation",
        default=True,
        description="Reset rotation to (0,0,0)"
    )

    origin_mode: bpy.props.EnumProperty(
        name="Origin",
        items=[
            ('CENTER', "Center of Volume", "Origin at volume center"),
            ('GEOMETRY', "Center of Geometry", "Origin at geometry center"),
        ],
        default='CENTER',
    )

    export_format: bpy.props.EnumProperty(
        name="Format",
        items=[
            ('GLB', "GLB (Binary)", "Single .glb file"),
            ('GLTF_SEPARATE', "glTF Separate", "JSON + BIN + textures"),
        ],
        default='GLB',
    )

    last_export_dir: bpy.props.StringProperty(
        name="Last Export Directory",
        default="",
        subtype="DIR_PATH",
        description="Last used export directory"
    )


class GMPStats(bpy.types.PropertyGroup):
    original_verts: bpy.props.IntProperty(
        name="Original Vertices",
        default=0,
        description="Original vertex count before optimization"
    )


# ---------------------------------------------------------
# Prepare Model (Modal)
# ---------------------------------------------------------

class OBJECT_OT_gmp_prepare_model_modal(bpy.types.Operator):
    bl_idname = "object.gmp_prepare_model"
    bl_label = "Prepare Model (Modal)"
    bl_description = "Cleanup, scale and decimate model in steps"
    bl_options = {'REGISTER', 'UNDO'}

    _timer = None
    _step = 0
    _total_steps = 4
    _wm = None

    def invoke(self, context, event):
        try:
            ensure_mesh(context)
        except Exception as e:
            self.report({'ERROR'}, str(e))
            return {'CANCELLED'}

        wm = context.window_manager
        self._wm = wm
        self._step = 0

        wm.progress_begin(0, self._total_steps)
        self._timer = wm.event_timer_add(0.1, window=context.window)
        wm.modal_handler_add(self)

        self.report({'INFO'}, "Preparing model…")
        return {'RUNNING_MODAL'}

    def modal(self, context, event):
        if event.type == 'ESC':
            self.finish()
            self.report({'WARNING'}, "Preparation cancelled")
            return {'CANCELLED'}

        if event.type != 'TIMER':
            return {'RUNNING_MODAL'}

        obj = ensure_mesh(context)
        scene = context.scene
        settings = scene.gmp_settings
        stats = scene.gmp_stats

        # Step 0 – store original verts
        if self._step == 0:
            stats.original_verts = len(obj.data.vertices)
            self._next("Cleaning mesh…")
            return {'RUNNING_MODAL'}

        # Step 1 – cleanup
        elif self._step == 1:
            bpy.ops.object.mode_set(mode='EDIT')
            bpy.ops.mesh.select_all(action='SELECT')
            merge_by_distance_auto(obj, dist=0.0001)
            bpy.ops.mesh.delete_loose()
            bpy.ops.mesh.normals_make_consistent()
            bpy.ops.object.mode_set(mode='OBJECT')
            self._next("Scaling to target size…")
            return {'RUNNING_MODAL'}

        # Step 2 – scaling
        elif self._step == 2:
            bbox = obj.bound_box
            coords = [obj.matrix_world @ Vector(corner) for corner in bbox]

            sx = max(c.x for c in coords) - min(c.x for c in coords)
            sy = max(c.y for c in coords) - min(c.y for c in coords)
            sz = max(c.z for c in coords) - min(c.z for c in coords)

            largest = max(sx, sy, sz)
            if largest > 0:
                f = settings.target_size / largest
                obj.scale = (f, f, f)
                bpy.ops.object.transform_apply(scale=True)

            self._next("Decimating geometry…")
            return {'RUNNING_MODAL'}

        # Step 3 – decimate
        elif self._step == 3:
            dec = obj.modifiers.new("GMP_Decimate", "DECIMATE")
            dec.ratio = settings.decimate_ratio
            dec.use_collapse_triangulate = True
            bpy.ops.object.modifier_apply(modifier=dec.name)
            self._next("Finalizing…")
            return {'RUNNING_MODAL'}

        # Finished
        else:
            self.finish()
            self.report({'INFO'}, "Model prepared ✔")
            return {'FINISHED'}

    def _next(self, text):
        self._step += 1
        if self._wm:
            self._wm.progress_update(self._step)
        self.report({'INFO'}, f"Step {self._step}/{self._total_steps} — {text}")

    def finish(self):
        if self._wm and self._timer:
            self._wm.event_timer_remove(self._timer)
            self._wm.progress_end()
        self._wm = None
        self._timer = None


# ---------------------------------------------------------
# Repair Mesh (Modal)
# ---------------------------------------------------------

class OBJECT_OT_gmp_mesh_repair_modal(bpy.types.Operator):
    bl_idname = "object.gmp_mesh_repair_modal"
    bl_label = "Repair Mesh (Modal)"
    bl_description = "Repair mesh in several steps"
    bl_options = {'REGISTER', 'UNDO'}

    _timer = None
    _step = 0
    _total_steps = 4
    _wm = None

    def invoke(self, context, event):
        try:
            ensure_mesh(context)
        except Exception as e:
            self.report({'ERROR'}, str(e))
            return {'CANCELLED'}

        wm = context.window_manager
        self._wm = wm
        self._step = 0

        wm.progress_begin(0, self._total_steps)
        self._timer = wm.event_timer_add(0.1, window=context.window)
        wm.modal_handler_add(self)

        self.report({'INFO'}, "Repairing mesh…")
        return {'RUNNING_MODAL'}

    def modal(self, context, event):
        if event.type == 'ESC':
            self.finish()
            self.report({'WARNING'}, "Repair cancelled")
            return {'CANCELLED'}

        if event.type != 'TIMER':
            return {'RUNNING_MODAL'}

        obj = ensure_mesh(context)
        settings = context.scene.gmp_settings

        # Step 0 – select all
        if self._step == 0:
            bpy.ops.object.mode_set(mode='EDIT')
            bpy.ops.mesh.select_all(action='SELECT')
            self._next("Removing doubles…")
            return {'RUNNING_MODAL'}

        # Step 1 – merge & delete loose
        elif self._step == 1:
            merge_by_distance_auto(obj, dist=0.0001)
            bpy.ops.mesh.delete_loose()
            self._next("Fixing degenerate / filling holes…")
            return {'RUNNING_MODAL'}

        # Step 2 – degenerate & holes
        elif self._step == 2:
            bpy.ops.mesh.dissolve_degenerate()
            bpy.ops.mesh.fill_holes(sides=0)
            self._next("Recalculating normals…")
            return {'RUNNING_MODAL'}

        # Step 3 – normals & optional triangulate
        elif self._step == 3:
            bpy.ops.mesh.normals_make_consistent()
            bpy.ops.object.mode_set(mode='OBJECT')

            if settings.triangulate:
                tri = obj.modifiers.new("GMP_Tri", "TRIANGULATE")
                bpy.ops.object.modifier_apply(modifier=tri.name)

            self._next("Finalizing…")
            return {'RUNNING_MODAL'}

        else:
            self.finish()
            self.report({'INFO'}, "Mesh repaired ✔")
            return {'FINISHED'}

    def _next(self, text):
        self._step += 1
        if self._wm:
            self._wm.progress_update(self._step)
        self.report({'INFO'}, f"Step {self._step}/{self._total_steps} — {text}")

    def finish(self):
        if self._wm and self._timer:
            self._wm.event_timer_remove(self._timer)
            self._wm.progress_end()
        self._wm = None
        self._timer = None


# ---------------------------------------------------------
# Shading Fix
# ---------------------------------------------------------

class OBJECT_OT_gmp_shading_fix(bpy.types.Operator):
    bl_idname = "object.gmp_shading_fix"
    bl_label = "Fix Shading"
    bl_description = "Smooth shading, auto smooth and normals fix"
    bl_options = {'REGISTER', 'UNDO'}

    def execute(self, context):
        obj = ensure_mesh(context)
        settings = context.scene.gmp_settings

        bpy.ops.object.shade_smooth()
        obj.data.use_auto_smooth = True
        obj.data.auto_smooth_angle = math.radians(settings.autosmooth_angle)

        bpy.ops.object.mode_set(mode='EDIT')
        bpy.ops.mesh.select_all(action='SELECT')
        bpy.ops.mesh.normals_make_consistent()
        bpy.ops.object.mode_set(mode='OBJECT')

        self.report({'INFO'}, "Shading fixed ✔")
        return {'FINISHED'}


# ---------------------------------------------------------
# Position
# ---------------------------------------------------------

class OBJECT_OT_gmp_center_object(bpy.types.Operator):
    bl_idname = "object.gmp_center_object"
    bl_label = "Center / Align Object"
    bl_description = "Origin, position, rotation alignment"
    bl_options = {'REGISTER', 'UNDO'}

    def execute(self, context):
        obj = ensure_mesh(context)
        settings = context.scene.gmp_settings

        if settings.origin_mode == 'CENTER':
            bpy.ops.object.origin_set(type='ORIGIN_CENTER_OF_VOLUME')
        else:
            bpy.ops.object.origin_set(type='ORIGIN_GEOMETRY')

        if settings.pos_snap_floor:
            min_z = min(v.co.z for v in obj.data.vertices)
            obj.location.z -= min_z

        if settings.pos_move_to_origin:
            obj.location.x = 0.0
            obj.location.y = 0.0

        if settings.pos_zero_rotation:
            obj.rotation_euler = (0.0, 0.0, 0.0)

        self.report({'INFO'}, "Object aligned ✔")
        return {'FINISHED'}


# ---------------------------------------------------------
# Export
# ---------------------------------------------------------

class OBJECT_OT_gmp_export_model(bpy.types.Operator):
    bl_idname = "object.gmp_export_model"
    bl_label = "Export Model"
    bl_description = "Export active mesh as GLB or glTF"
    bl_options = {'REGISTER', 'UNDO'}

    export_to_docs: bpy.props.BoolProperty(
        name="Export to Documents",
        default=False,
        description="If true, export to Documents/BarbarossaGamePrep/exports"
    )

    def draw(self, context):
        layout = self.layout
        col = layout.column()
        col.label(text="Your .blend file is not saved.", icon="INFO")
        col.label(text="Export will go to:")
        col.label(text="Documents/BarbarossaGamePrep/exports", icon="FILE_FOLDER")

    def _compute_dir(self, context):
        settings = context.scene.gmp_settings

        if self.export_to_docs or not bpy.data.filepath:
            base = os.path.join(
                os.path.expanduser("~"), "Documents", "BarbarossaGamePrep", "exports"
            )
        else:
            base = os.path.join(bpy.path.abspath("//"), "exports")

        os.makedirs(base, exist_ok=True)
        settings.last_export_dir = base
        return base

    def invoke(self, context, event):
        if not bpy.data.filepath:
            self.export_to_docs = True
            return context.window_manager.invoke_props_dialog(self, width=420)

        return self.execute(context)

    def execute(self, context):
        obj = ensure_mesh(context)
        settings = context.scene.gmp_settings

        # only export this object
        for o in context.selected_objects:
            o.select_set(False)
        obj.select_set(True)
        context.view_layer.objects.active = obj

        base = self._compute_dir(context)
        safe = bpy.path.clean_name(obj.name)

        if settings.export_format == 'GLB':
            path = os.path.join(base, safe + ".glb")
            bpy.ops.export_scene.gltf(
                filepath=path,
                export_format='GLB',
                use_selection=True,
            )
        else:
            path = os.path.join(base, safe + ".gltf")
            bpy.ops.export_scene.gltf(
                filepath=path,
                export_format='GLTF_SEPARATE',
                use_selection=True,
            )

        self.report({'INFO'}, f"Exported: {path}")
        return {'FINISHED'}


class OBJECT_OT_gmp_open_export_folder(bpy.types.Operator):
    bl_idname = "object.gmp_open_export_folder"
    bl_label = "Open Export Folder"
    bl_description = "Open last export folder in file manager"

    def execute(self, context):
        settings = context.scene.gmp_settings
        path = settings.last_export_dir

        if not path or not os.path.isdir(path):
            if bpy.data.filepath:
                path = os.path.join(bpy.path.abspath("//"), "exports")
            else:
                path = os.path.join(
                    os.path.expanduser("~"), "Documents", "BarbarossaGamePrep", "exports"
                )
            os.makedirs(path, exist_ok=True)
            settings.last_export_dir = path

        bpy.ops.wm.path_open(filepath=path)
        return {'FINISHED'}


# ---------------------------------------------------------
# Panels
# ---------------------------------------------------------

class VIEW3D_PT_gmp_stats(bpy.types.Panel):
    bl_label = "Mesh Stats"
    bl_idname = "VIEW3D_PT_gmp_stats"
    bl_space_type = 'VIEW_3D'
    bl_region_type = 'UI'
    bl_category = "Game Prep"

    def draw(self, context):
        layout = self.layout
        obj = context.active_object
        stats = context.scene.gmp_stats

        box = layout.box()
        if obj and obj.type == 'MESH':
            current = len(obj.data.vertices)
            original = stats.original_verts or current
            reduction = int((1 - current / original) * 100) if original > 0 else 0

            box.label(text=f"Original vertices: {original}")
            box.label(text=f"Current vertices:  {current}")
            box.label(text=f"Reduction:         {reduction}%")
        else:
            box.label(text="Select a mesh to show statistics.")


class VIEW3D_PT_gmp_optimize(bpy.types.Panel):
    bl_label = "Optimize (Modal)"
    bl_idname = "VIEW3D_PT_gmp_optimize"
    bl_space_type = 'VIEW_3D'
    bl_region_type = 'UI'
    bl_category = "Game Prep"

    def draw(self, context):
        layout = self.layout
        settings = context.scene.gmp_settings

        layout.label(text="Size & Polycount:")
        col = layout.column(align=True)
        col.prop(settings, "target_size")
        col.prop(settings, "decimate_ratio")
        col.operator("object.gmp_prepare_model", icon="MODIFIER")


class VIEW3D_PT_gmp_shading(bpy.types.Panel):
    bl_label = "Shading"
    bl_idname = "VIEW3D_PT_gmp_shading"
    bl_space_type = 'VIEW_3D'
    bl_region_type = 'UI'
    bl_category = "Game Prep"

    def draw(self, context):
        layout = self.layout
        settings = context.scene.gmp_settings

        layout.label(text="Normals & Smooth:")
        col = layout.column(align=True)
        col.prop(settings, "autosmooth_angle")
        col.operator("object.gmp_shading_fix", icon="MATERIAL")


class VIEW3D_PT_gmp_repair(bpy.types.Panel):
    bl_label = "Repair (Modal)"
    bl_idname = "VIEW3D_PT_gmp_repair"
    bl_space_type = 'VIEW_3D'
    bl_region_type = 'UI'
    bl_category = "Game Prep"

    def draw(self, context):
        layout = self.layout
        settings = context.scene.gmp_settings

        layout.label(text="Mesh Cleanup:")
        col = layout.column(align=True)
        col.prop(settings, "triangulate")
        col.operator("object.gmp_mesh_repair_modal", icon="RECOVER_LAST")


class VIEW3D_PT_gmp_position(bpy.types.Panel):
    bl_label = "Position"
    bl_idname = "VIEW3D_PT_gmp_position"
    bl_space_type = 'VIEW_3D'
    bl_region_type = 'UI'
    bl_category = "Game Prep"

    def draw(self, context):
        layout = self.layout
        settings = context.scene.gmp_settings

        layout.label(text="Origin & Transform:")
        col = layout.column(align=True)
        col.prop(settings, "origin_mode")
        col.prop(settings, "pos_move_to_origin")
        col.prop(settings, "pos_snap_floor")
        col.prop(settings, "pos_zero_rotation")
        col.operator("object.gmp_center_object", icon="PIVOT_CURSOR")


class VIEW3D_PT_gmp_export(bpy.types.Panel):
    bl_label = "Export"
    bl_idname = "VIEW3D_PT_gmp_export"
    bl_space_type = 'VIEW_3D'
    bl_region_type = 'UI'
    bl_category = "Game Prep"

    def draw(self, context):
        layout = self.layout
        settings = context.scene.gmp_settings

        layout.label(text="Export to safe folder:")
        layout.prop(settings, "export_format")
        row = layout.row(align=True)
        row.operator("object.gmp_export_model", icon="EXPORT")
        row.operator("object.gmp_open_export_folder", icon="FILE_FOLDER")

        if settings.last_export_dir:
            layout.label(text=f"Last path: {settings.last_export_dir}", icon="INFO")


class VIEW3D_PT_gmp_info(bpy.types.Panel):
    bl_label = "Info / Help"
    bl_idname = "VIEW3D_PT_gmp_info"
    bl_space_type = 'VIEW_3D'
    bl_region_type = 'UI'
    bl_category = "Game Prep"

    def draw(self, context):
        layout = self.layout
        layout.label(text="Prepare Model (Modal):", icon="MODIFIER")
        layout.label(text="- Cleanup, Scale, Decimate")

        layout.separator()
        layout.label(text="Repair Mesh (Modal):", icon="RECOVER_LAST")
        layout.label(text="- Remove Doubles, Delete Loose")
        layout.label(text="- Fix Degenerate, Fill Holes")

        layout.separator()
        layout.label(text="Shading:", icon="MATERIAL")
        layout.label(text="- Smooth shading, auto smooth, normals")

        layout.separator()
        layout.label(text="Position:", icon="PIVOT_CURSOR")
        layout.label(text="- Set Origin, Move to (0,0,0), Snap to floor")

        layout.separator()
        layout.label(text="Export:", icon="EXPORT")
        layout.label(text="- GLB / glTF Separate")
        layout.label(text="- Safe export folder & open button")


# ---------------------------------------------------------
# Registration
# ---------------------------------------------------------

classes = (
    GMPSettings,
    GMPStats,
    OBJECT_OT_gmp_prepare_model_modal,
    OBJECT_OT_gmp_mesh_repair_modal,
    OBJECT_OT_gmp_shading_fix,
    OBJECT_OT_gmp_center_object,
    OBJECT_OT_gmp_export_model,
    OBJECT_OT_gmp_open_export_folder,
    VIEW3D_PT_gmp_stats,
    VIEW3D_PT_gmp_optimize,
    VIEW3D_PT_gmp_shading,
    VIEW3D_PT_gmp_repair,
    VIEW3D_PT_gmp_position,
    VIEW3D_PT_gmp_export,
    VIEW3D_PT_gmp_info,
)


def register():
    for cls in classes:
        bpy.utils.register_class(cls)

    bpy.types.Scene.gmp_settings = bpy.props.PointerProperty(type=GMPSettings)
    bpy.types.Scene.gmp_stats = bpy.props.PointerProperty(type=GMPStats)

    print("Game Model Prep v3.1.5 registered")


def unregister():
    for cls in reversed(classes):
        try:
            bpy.utils.unregister_class(cls)
        except Exception:
            pass

    if hasattr(bpy.types.Scene, "gmp_settings"):
        del bpy.types.Scene.gmp_settings
    if hasattr(bpy.types.Scene, "gmp_stats"):
        del bpy.types.Scene.gmp_stats

    print("Game Model Prep v3.1.5 unregistered")


if __name__ == "__main__":
    register()
